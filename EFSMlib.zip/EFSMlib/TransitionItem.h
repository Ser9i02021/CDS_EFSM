#pragma once
#include <QGraphicsPathItem>
class StateItem;

class TransitionItem : public QGraphicsPathItem {
public:
    explicit TransitionItem(StateItem* src, StateItem* dst, QGraphicsItem* parent=nullptr);

    StateItem* src() const { return src_; }
    StateItem* dst() const { return dst_; }

    int priority() const { return priority_; }
    const QString& guard()  const { return guard_; }
    const QString& action() const { return action_; }
    const QString& label()  const { return label_; }

    void setPriority(int p){ priority_=p; updateLabel(); }
    void setGuard(const QString& g){ guard_=g; updateLabel(); }
    void setAction(const QString& a){ action_=a; updateLabel(); }
    void setLabel(const QString& l){ label_=l; updateLabel(); }

    void updatePath(); // recalc line & arrow

    int id() const { return id_; }    // <- NOVO

protected:
    void mouseDoubleClickEvent(QGraphicsSceneMouseEvent* e) override;

private:
    void updateLabel();

    StateItem* src_{};
    StateItem* dst_{};
    int priority_{1};
    QString guard_{"true"};
    QString action_{};
    QString label_{};
    QGraphicsSimpleTextItem* text_{nullptr};

    int id_{0};               // <- NOVO
    static int s_nextId_;     // <- NOVO
};
