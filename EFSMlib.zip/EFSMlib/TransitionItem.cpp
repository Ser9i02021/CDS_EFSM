#include "TransitionItem.h"
#include "TransitionEditorDialog.h"
#include "StateItem.h"
#include <QGraphicsSceneMouseEvent>
#include <QGraphicsScene>
#include <QGraphicsSimpleTextItem>
#include <QLineF>
#include <QPainterPath>
#include <QtMath>
#include <cmath>
#include <QGraphicsView>   // <- necessário para scene()->views().first()
#include <QWidget>         // opcional, só para o tipo QWidget*

int TransitionItem::s_nextId_ = 0;

TransitionItem::TransitionItem(StateItem* s, StateItem* d, QGraphicsItem* parent)
    : QGraphicsPathItem(parent), src_(s), dst_(d)
{
    id_ = ++s_nextId_;                    // <- NOVO
    setZValue(-1); // atrás dos estados
    setPen(QPen(Qt::black, 1.3));
    setFlags(QGraphicsItem::ItemIsSelectable);
    text_ = new QGraphicsSimpleTextItem(this);
    text_->setFlag(QGraphicsItem::ItemIgnoresTransformations);
    updatePath();
    updateLabel();
}

void TransitionItem::updatePath(){
    if (!src_ || !dst_) return;
    const QPointF A = src_->scenePos();
    const QPointF B = dst_->scenePos();

    QPainterPath p(A);
    p.lineTo(B);

    // cabeça de seta
    QLineF line(A,B);
    double angle = std::atan2(-line.dy(), line.dx());
    const double arrow = 12.0;
    QPointF p1 = B + QPointF(std::sin(angle - M_PI/3)*arrow, std::cos(angle - M_PI/3)*arrow);
    QPointF p2 = B + QPointF(std::sin(angle - M_PI + M_PI/3)*arrow, std::cos(angle - M_PI + M_PI/3)*arrow);
    QPainterPath head(B);
    head.moveTo(p1); head.lineTo(B); head.lineTo(p2);

    QPainterPath all = p;
    all.addPath(head);
    setPath(all);

    // posiciona o texto no meio
    auto b = text_->boundingRect();
    QPointF mid = (A+B)/2;
    text_->setPos(mid.x()-b.width()/2, mid.y()-b.height()-6);
}

void TransitionItem::updateLabel(){
    QString t;
    if (!label_.isEmpty()) t += label_ + "  ";
    t += QString("[%1] ").arg(priority_) +
         (guard_.isEmpty() ? "true" : guard_) +
         " / " +
         (action_.isEmpty() ? "/*no-op*/" : action_);
    text_->setText(t);
    // reposiciona baseado no novo tamanho
    if (src_ && dst_) {
        auto b = text_->boundingRect();
        QPointF mid = (src_->scenePos()+dst_->scenePos())/2;
        text_->setPos(mid.x()-b.width()/2, mid.y()-b.height()-6);
    }
}

void TransitionItem::mouseDoubleClickEvent(QGraphicsSceneMouseEvent* e){
    QWidget* parentWidget = nullptr;
    if (scene() && !scene()->views().isEmpty()) parentWidget = scene()->views().first();
    TransitionEditorDialog dlg(parentWidget);
    dlg.setValues(priority_, guard_, action_, label_);
    if (dlg.exec()==QDialog::Accepted){
        setPriority(dlg.priority());
        setGuard(dlg.guard());
        setAction(dlg.action());
        setLabel(dlg.label());
    }
    QGraphicsPathItem::mouseDoubleClickEvent(e);
}
