#include "DiagramScene.h"
#include "StateItem.h"
#include "TransitionItem.h"
#include "TransitionEditorDialog.h"
#include <QGraphicsSceneMouseEvent>
#include <QPen>
#include <QGraphicsView>   // <- necessário para scene()->views().first()
#include <QWidget>         // opcional, só para o tipo QWidget*

DiagramScene::DiagramScene(QObject* parent) : QGraphicsScene(parent) {}

void DiagramScene::setMode(Mode m){
    mode_ = m;
    if (tempLine_) { removeItem(tempLine_); delete tempLine_; tempLine_ = nullptr; }
    pendingSrc_ = nullptr;
}

void DiagramScene::mousePressEvent(QGraphicsSceneMouseEvent* e){
    if (mode_ == Mode::AddTransition){
        pendingSrc_ = stateAt(e->scenePos());
        if (pendingSrc_){
            tempLine_ = addLine(QLineF(e->scenePos(), e->scenePos()),
                                QPen(Qt::darkGray, 1, Qt::DashLine));
            return; // não passa para base
        }
    }
    QGraphicsScene::mousePressEvent(e);
}

void DiagramScene::mouseMoveEvent(QGraphicsSceneMouseEvent* e){
    if (tempLine_){
        auto l = tempLine_->line();
        l.setP2(e->scenePos());
        tempLine_->setLine(l);
        return;
    }
    QGraphicsScene::mouseMoveEvent(e);
}

void DiagramScene::mouseReleaseEvent(QGraphicsSceneMouseEvent* e){
    if (tempLine_){
        removeItem(tempLine_); delete tempLine_; tempLine_ = nullptr;
        auto dst = stateAt(e->scenePos());
        if (pendingSrc_ && dst && dst!=pendingSrc_){
            auto t = new TransitionItem(pendingSrc_, dst);
            addItem(t);
            t->updatePath();

            // abre editor para já preencher guard/ação/prioridade
            QWidget* parentWidget = nullptr;
            if (!views().isEmpty()) parentWidget = views().first();
            TransitionEditorDialog dlg(parentWidget);
            dlg.setValues(1, "true", "", "");
            if (dlg.exec()==QDialog::Accepted){
                t->setPriority(dlg.priority());
                t->setGuard(dlg.guard());
                t->setAction(dlg.action());
                t->setLabel(dlg.label());
            }
        }
        pendingSrc_ = nullptr;
        return;
    }
    QGraphicsScene::mouseReleaseEvent(e);
}

StateItem* DiagramScene::stateAt(const QPointF& p) const{
    for (auto* it : items(p)) if (auto s = dynamic_cast<StateItem*>(it)) return s;
    return nullptr;
}
